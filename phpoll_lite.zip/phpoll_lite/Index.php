<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GE Life Science</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico" />

</head>
<body>
<style>

    body {
        background-image: url('images/logopicture.jpg');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-position: right top;
        background-color: white;
        background-size: 50%;
        font-family: Arial;
        font-size: medium;
    }
</style>

<h1 style="color:  #3a5dae; font-size: 50px;text-align: left;">GE Life Science Quiz </h1><br><br><br><br><br><br><br><br><br>
<h2 style="font-size: 30px;text-align: center;">Please get ready on your phone!
</h2>
<form style="text-align: center;">
<select name="cars" style="font-size: 20px;">
    <option value="volvo">Quiz 1</option>
    <option value="saab">Quiz 2</option>
    <option value="fiat">Quiz 3</option>
    <option value="audi">Quiz 4</option>
</select>
</form>
<form style="text-align: center;margin-top: 40px;" action="poll.php" >
    <button style="color: #3a5dae;
font-weight: bold;
  font-size: 150%;
  text-transform: uppercase;" value="Start">Start</button>
</form>
</body>
</html>

