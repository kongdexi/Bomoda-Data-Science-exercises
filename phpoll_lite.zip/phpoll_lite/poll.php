<!DOCTYPE html>

<html>
    <head>
        <title>GE Life Science Quiz</title>
        <link rel="stylesheet" type="text/css" href="css/poll.css"/>
        <link rel="icon" type="image/x-icon" href="images/favicon.ico" />
        <script src="./js/jquery-3.2.1.min.js"></script>
        <script src="./js/highcharts.js"></script>
        <script src="./js/exporting.js"></script>
        <script src="./js/data.js"></script>
        <script src="./js/timer.js"></script>
        <script src="./js/script.js"></script>
    </head>
    <body>
    <!--LS Logo & Next Button-->
        <div id="header">
            <img src="images/gels.jpg" style="height:100px;width:auto;">
            <p id="timer" style="color: darkred; font-weight: bold; float:right;padding-right: 30px;"></p>
            <br>
            <form style="float: right; height: 2em;padding-right: 1em;">
                <a onclick="next();" id= "next" style="display: block;" class="button lightbg-blue clearfix">Next
                    <div class="icon">
                        <div class="arrow"></div>
                    </div></a>
            </form>
        </div>
        <br><br><br>
        <!--    Questions and choices-->
        <div id="quizpage">
            <h2 id="print"></h2>
            <div class="choices">
                <ul id="demos"></ul>
            </div>
        </div>
        <!--     Result switch   Buttons-->
        <label class="switch">
            <input class="result" type="checkbox" onclick="showresult(); hidenext();">
            <span class="slider"></span>
        </label>
        <!--  Link to Top 5 page-->
         <form action="Top5.php" style="float: right;">
             <input id="top5" type="submit" class="button lightbg-blue clearfix" value="Show Top5" style="height: 50px;padding-right:20px;display: none;">
         </form>
        <!--Highcharts Container-->
        <div id="container" style="display: none;"></div>
    </body>
</html>
