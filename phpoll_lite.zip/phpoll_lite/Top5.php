<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script>
    $(document).ready(function() {
        var top5 = Highcharts.chart('top5charts', {
            chart: {
                type: 'bar'
            },
            title: {
                text: 'Top5 Highest Score'
            },
            xAxis: {
                categories: ['Dexi', 'Mike', 'John', 'Durant', 'Curry'],
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: 'points'
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {enabled:false
            },
            credits: {
                enabled: false
            },
            series: [{
                data: [98, 90, 88, 85, 80]
            }]
        })
    });

</script>

<div id="top5charts" style="min-width: 310px; max-width: 800px; height: 400px; margin: 0 auto"></div>
