
// ########display questions & Results############################
var nextElement;
window.onload = function () {
    var print = document.getElementById("print");
    var demop = document.getElementById("demos");
    var a;

//Print first value of array right away.
    print.innerHTML = quiz[current].name;

    for (a = 0; a <= quiz[current].choice.length - 1; a++) {
        demop.innerHTML +=
            "<li>" +
            "<input type=\"radio\" id=\"" + a + "\"name=\"selector\">" +
            "<label for=\"" + a + "\">" + quiz[current].choice[a] + "</label>" +

            "<div class=\"check\"><div class=\"inside\"></div></div>" +
            "</li>";
    }

     nextElement = function() {
        print.innerHTML = quiz[current].name;
        demop.innerHTML = '';

        for (a = 0; a <= quiz[current].choice.length - 1; a++) {
            demop.innerHTML +=
                "<li>" +
                "<input type=\"radio\" id=\"" + a + "\"name=\"selector\">" +
                "<label for=\"" + a + "\">" + quiz[current].choice[a] + "</label>" +

                "<div class=\"check\"><div class=\"inside\"></div></div>" +
                "</li>";

        }
        countDownDate = new Date().getTime() + 20000;
    }
}
// ####################Next Page / Results###########
var current=0;
function next()
{
    current = current+1;
    if(current>=quiz.length){
        alert('This is the Last Question!');
        return;
    }
    countDownDate = new Date().getTime() + 20000;
    nextElement();
    nextChart();

    console.log(quiz.length);
    console.log(current);
    if(current==(quiz.length-1)){
        var top5 = document.getElementById('top5');
        top5.style.display = 'block';

    }
};
function showresult() {
    var x = document.getElementById('container');
//            var y = document.getElementById('demos');
    if (x.style.display === 'none') {
        x.style.display = 'block';
        document.body.scrollTop = document.body.scrollHeight;
//                window.scrollTo(0,document.body.scrollHeight);

    } else {
        x.style.display = 'none';
    }
}
function hidenext() {

    var x = document.getElementById('next');
    if (x.style.display == 'block') {
        x.style.display = 'none';
    }else{
        x.style.display = 'block';
    }
};




// ###########Display Highcharts########################



var options = {
    chart: {
        renderTo: 'container',
        type: 'bar',
        height:800,

    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    legend: {
        enabled: false
    },
    xAxis: {
        categories: [],
        crosshair: true,
        labels: {
            style: {
                color: '#3a5dae',
                fontSize: "20px"
            }
        }
    },
    series: [{}]
};


options.series[0].data = quiz[current].votes;
options.title.text = quiz[current].name;
options.subtitle.text = quiz[current].quiz;
options.xAxis.categories = quiz[current].choice;



$(document).ready(function() {
    var chart = new Highcharts.Chart(options);
});

function nextChart(){
    options.series[0].data = quiz[current].votes;
    options.title.text = quiz[current].name;
    options.subtitle.text = quiz[current].quiz;
    options.xAxis.categories = quiz[current].choice;
    $(document).ready(function() {
        var chart = new Highcharts.Chart(options);
    });

}


// ##################################

