
var quiz = [
    {
        "id":1,
        "name":"1. 医学影像设备有哪些？",
        "questionTypeId":1,
        "quiz":"OMVIS新员工培训-CI落地考",
        "isAnswer":[false,false,false,true],
        "choice":["A. X-ray",
            "B. CT X线计算机体层成像",
            "C. MRI磁共振成像",
            "D. USG超声成像",
            "E. ECT 发射型计算机体层成像"
        ],
        "votes": [20, 10, 5, 60,20]
    }
    ,

    {
        "id":2,
        "name":"2. 使用对比剂方法？",
        "questionTypeId":1,
        "quiz":"OMVIS新员工培训-CI落地考",
        "isAnswer":[false,false,true,false],
        "choice":["A. 口服",
            "B. 灌注",
            "C. 穿刺注入",
            "D. 病理通道输入"
        ],
        "votes": [30, 40, 79, 60]
    }
    ,
    {
        "id":3,
        "name":"3. X线对比剂的特点，正确的是",
        "questionTypeId":1,
        "quiz":"OMVIS新员工培训-CI落地考",
        "isAnswer":[false,false,true,false],
        "choice":["A. 对比剂是药理学精心设计的具有一定治疗作用的化学制剂",
            "B. 没有其他药物像对比剂那样短时间大量注入人体",
            "C. 36小时内，98%以上原形排出",
            "D. 经肾脏排出"

],
        "votes": [30, 40, 79, 60]
    }
    ,
    {
        "id":4,
        "name":"4. 对比剂发展史，正确的是:",
        "questionTypeId":1,
        "quiz":"OMVIS新员工培训-CI落地考",
        "isAnswer":[false,false,true,false],
        "choice":["A. 碳酸钙-硫酸钡-碘油/碘化钠-泛影酸盐-离子单体-离子双体-离子双体等渗对比剂",
                  "B. 碳酸钙-硫酸钡-泛影酸盐-碘油/碘化钠-非离子单体-非离子双体等渗对比剂-非离子双体对比剂",
                  "C. 碳酸钙-硫酸钡-碘油/碘化钠-泛影酸盐-非离子单体-非离子双体对比剂-离子型双体等渗对比剂-",
                  "D. 碳酸钙-硫酸钡-碘油/碘化钠-泛影酸盐-非离子单体/双体-非离子双体等渗对比剂"
                ],
        "votes": [30, 40, 79, 60]
    }
];